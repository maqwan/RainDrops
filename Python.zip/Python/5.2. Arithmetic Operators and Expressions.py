# 5.2. Arithmetic Operators and Expressions
#
# 1. Write a program that creates two variables, num1 and num2. Both
# num1 and num2 should be assigned the integer literal 25000000, one
# written with underscores and one without. Print num1 and num2 on
# two separate lines.

# 2. Write a program that assigns the floating-point literal 175000.0 to
# the variable num using E notation and then prints num in the interactive
# window.

# 3. In IDLE’s interactive window, try to find the smallest exponent N
# for which 2e<N>, where <N> is replaced with your number, returns
# inf.

# <1>
##number_one = 25000000
##number_two = 25_000_000
##
##print(number_one)
##print(number_two)
# </1>

#<2>
##number_one = 175e3
##
##print(number_one)
#</2>


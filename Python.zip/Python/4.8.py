# startswith()
# he startswith() string method checks whether a string starts with a
# particular substring. If the string starts with a
# specified substring, the startswith() method returns True; otherwise, the function returns False

# .endswith()
# The endswith() method returns a boolean. It returns True if
# a string ends with the specified suffix. It returns False if
# a string doesn't end with the specified suffix.

# .upper()
# sets entire string to uppercase

# .lower()
# sets entire string to lower case

# .rstrip()
# The rstrip() method removes any trailing characters (characters at the end a string), space is the default trailing character to remove.

# .lstrip()
# The lstrip() method returns a copy of the string with leading characters removed (based on the string argument passed). The lstrip()
# removes characters from the left based on the argument (a string specifying the set of characters to be removed)

# .strip()
# The strip() method removes any leading (spaces at the beginning) and trailing (spaces at the end) characters (space is the default leading character to remove)

# .find("string to find")

# .replace()
# replace("true","false") replaced a string. fx to to false

# F string, or what would be called string interpolation in C#
# print(f"the answer is {answer}")

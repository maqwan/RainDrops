first_name = "Martin "
last_name = " Westermann"

first_name.lower().startswith("m")

print(last_name.lower().endswith("mann"))


animals = "Animals"
bader = "Badger"
honey_bee = "Honey Bee"
honey_badger = "Honey Badger"

print(animals.lower())
print(bader.lower())
print(honey_bee.lower())
print(honey_badger.lower())

print(animals.upper())
print(bader.upper())
print(honey_bee.upper())
print(honey_badger.upper())

string1 = " Filet Mignon"
string2 = "Brisket "
string3 = " Cheeseburger "

print(string1.lstrip())
print(string2.rstrip())
print(string3.strip())

string11 = "Becomes"
string22 = "becomes"
string33 = "BEAR"
string44 = " bEautiful"

print(string11.lower().startswith("be"))
print(string22.lower().startswith("be"))
print(string33.lower().startswith("be"))
print(string44.lower().lstrip().startswith("be"))

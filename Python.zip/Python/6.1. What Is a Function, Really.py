#!/usr/bin/env python3

def multi(x,y):
    product = x *y
    return product



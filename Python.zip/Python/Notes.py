# startswith()
# he startswith() string method checks whether a string starts with a
# particular substring. If the string starts with a
# specified substring, the startswith() method returns True; otherwise, the function returns False

# .endswith()
# The endswith() method returns a boolean. It returns True if
# a string ends with the specified suffix. It returns False if
# a string doesn't end with the specified suffix.

# .upper()
# sets entire string to uppercase

# .lower()
# sets entire string to lower case

# .rstrip()
# The rstrip() method removes any trailing characters (characters at the end a string), space is the default trailing character to remove.

# .lstrip()
# The lstrip() method returns a copy of the string with leading characters removed (based on the string argument passed). The lstrip()
# removes characters from the left based on the argument (a string specifying the set of characters to be removed)

# .strip()
# The strip() method removes any leading (spaces at the beginning) and trailing (spaces at the end) characters (space is the default leading character to remove)

# .find("string to find")

# .replace()
# replace("true","false") replaced a string. fx to to false

# F string, or what would be called string interpolation in C#
# print(f"the answer is {answer}")
# 

#1. round(), for rounding numbers to some number of decimal places... first argument = the number = is amount if decimals
#2. abs(), for getting the absolute value of a number
# 3. pow(), for raising a number to some power

#>>> num = 2.5
#>>> num.is_integer()
#False
#>>> num = 2.0
#>>> num.is_integer()
#True


# floats must be seperated by a dot . and not a comma , 

#f"The value of n is {n:.2f}"
#>>> n = 7.125
#>>> f"The value of n is {n}"
#'The value of n is 7.125'

#>>> n = 1
#>>> f"The value of n is {n:.2f}"
#'The value of n is 1.00'
#>>> f"The value of n is {n:.3f}"
#The value of n is 1.000'

#>>> n = 1234567890
#>>> f"The value of n is {n:,}"
#'The value of n is 1,234,567,890'

#>>> n = 1234.56
#>>> f"The value of n is {n:,.2f}"
#'The value of n is 1,234.56'

# decimal_output = 3 * .125
# print(f"the result is: {decimal_output:.3f}")
# the result is: 0.375

## currency = 1500000
## print(f"the value in ${currency:,.2f}")
## the value in $1,500,000.00

## percent = 2/10
## print(f"lets print it in style {percent:.2%}")
## lets print it in style 20.00%
##


##n = 6
##
##for n in range(n):
##    print(n)
##

## range(start, stop, step)
## start	Optional. An integer number specifying at which position to start. Default is 0
## stop	Required. An integer number specifying at which position to stop (not included).
## step	Optional. An integer number specifying the incrementation. Default is


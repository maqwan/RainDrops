# first Py Script
name = "Martin Westermann"
isTrue = True
counter = 0
while isTrue == True:
    print(name[:counter])
    counter = counter +1
    if counter == len(name):
        isTrue = False
        

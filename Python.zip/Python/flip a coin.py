#flip a coin
# variables to hold how many times its heads and tails
# loop 10000 times
### call random function to see
##
import random    

times = 1000

ones = 0
twos = 0
threes = 0
fours = 0
fives = 0
sixes = 0

def roll():
     value = int(random.randint(1,6))
     return value
     print(value)
 
for n in range(0,times,1):

    if roll() == 1:
      
        ones = ones +1
    if roll() == 2:
       
        twos = twos +1
    if roll() == 3:
     
        threes = threes +1
    if roll() == 4:
       
        fours = fours +1
    if roll() == 5:
      
        fives = fives +1
    if roll() == 6:
      
        sixes = sixes +1
print(n)
      
ones_pr = ones / times * 100
twos_pr = twos / times * 100
threes_pr = threes / times * 100
fours_pr = fours / times * 100
fives_pr = fives / times * 100
sixes_pr = sixes / times * 100

print(ones_pr)
print(twos_pr)
print(threes_pr)
print(fours_pr)
print(fives_pr)
print(sixes_pr)

total = ones_pr + twos_pr + threes_pr + fours_pr + fives_pr + sixes_pr

total_num  = ones + twos + threes + fours + fives + sixes
print(total)

print(total_num)

print(f"ones = {ones} two = {twos} threes = {threes} fours = {fours} fives = {fives} sixes = {sixes}")



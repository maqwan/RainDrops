# Challenge: Track Your Investments

def getFloat(message):
    return float(input(f"{message}: "))
    
def getInt(message):
    return int(input(f"{message}: "))          

def getInvestment():
    am = getFloat("please enter amount you want to invest")
    R = getFloat("please enter rate of investment")
    ye = getInt("please enter number of years")
    invest(am,R,ye)

def invest(amount, rate, years):
    print(f"your investment of {amount} will increase by {rate}% over a period of {years}")
    for n in range(0,years,1):
        invest_return = rate/100 * amount
        new_amount = amount + invest_return
        amount = new_amount
        print(f"the result is {new_amount:.2f} at year {n}")
        
       

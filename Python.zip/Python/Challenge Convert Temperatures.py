#6.3 Challenge: Convert Temperatures


def tempF():
    temp_input = float(input("input the temp in F: "))
    C = (temp_input - 32) * 5/9
    print(f"the temp in C is {C:.2f}")

def tempC():
    temp_input = float(input("input the temp in C: "))
    F = temp_input * 9/5 + 32
    print(f"the temp in F is {F}")
    



    
    


    
    









## guestbook


value = input("please enter a number: ")
    
 

            
        
        
        
   

def getString():
    print()

def getInfo():
    print()

    

def printGuestBook():
    print()


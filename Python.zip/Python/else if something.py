## Fizz Buzz


def RunFB():
    fb = getString("enter a fizz buzz value: ")
    FizzBuzz(fb)

def getString(message):
    value = input(f"{message}")
    return value


def FizzBuzz(value):
    if len(value) <= 3:
        print("Fizz")
    else:
        print("Buzz")

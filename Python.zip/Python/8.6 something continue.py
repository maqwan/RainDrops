##Using continue, write a program that loops over the numbers 1 to
##50 and prints all numbers that are not multiples of 3.

for n in range(0,50,1):
    if n % 3 == 0:
        print(str(n) + "true value")
    else:
        print(n)

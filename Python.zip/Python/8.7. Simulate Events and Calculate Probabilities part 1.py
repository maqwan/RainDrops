#8.7. Simulate Events and Calculate Probabilities part 1


while True:
    try:
       myValue = int(input("enter an int value: "))
       print(f"you entered {myValue}")
       break
    except ValueError:
        print("please enter a valid value")
        

    
    

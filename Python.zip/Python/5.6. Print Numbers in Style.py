# F string stuff



# decimal_output = 3 * .125
# print(f"the result is: {decimal_output:.3f}")
# the result is: 0.375

## currency = 1500000
## print(f"the value in ${currency:,.2f}")
## the value in $1,500,000.00

## percent = 2/10
## print(f"lets print it in style {percent:.2%}")
## lets print it in style 20.00%
##


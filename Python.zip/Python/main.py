i = 1
while True:
    i = i+1
    print(i)

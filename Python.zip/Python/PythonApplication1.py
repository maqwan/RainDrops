##def raiseToPower(num,powerOf):
##    return pow(num,powerOf)
##
##raiseToPower(2,2)
##raiseToPower(4,2)
##
##print(raiseToPower(2,2))
##print(raiseToPower(4,2))
##
##def greeting(first,last):
##    print(f"hello {first} {last}")
##
##first_name = input("what is your first name?: ")
##last_name = input("what is your last name?: ")
##
##greeting(first_name,last_name)

# 5.4 Make Python Lie to You

first_round = 5.236563

sec_round = 7.32546

third_round = 9.436321


print(f"3 decimal rounding: {round(first_round,3)} two decimal point rounding {round(first_round,2)} ")
print(f"3 decimal rounding: {round(sec_round ,3)} two decimal point rounding {round(sec_round ,2)} ")
print(f"3 decimal rounding: {round(third_round,3)} two decimal point rounding {round(third_round,2)} ")

get_abs_num1 = float(input("enter decimal number you want as absolute: "))

print(abs(get_abs_num1))


get_num1 = float(input("enter first number: "))
get_num2 = float(input("enter secound number: "))

isValidnumber = float(get_num1 - get_num2)
isTorF = bool(isValidnumber.is_integer())



print(f"The difference between {get_num1} and {get_num2} is an {isValidnumber}? is it an int? {isTorF}!")

                 
                 

## 4.4

password = input("Enter password: ")

first_letter = password[0].upper()

print("the password you entered was " +str(len(password))+ " charcters long"  + " the first letter is " + first_letter)


for n in range(2,10,1):
    print(n)

g = 2
while g < 11:
    print(f"the value of g is {g}")
    g = g+1



def double():
    text = float(input("please enter a number you want doubled 3 times: "))
    for n in range(0,3,1):
        text = text *2
        print(text)

## this is so much fun

first_name = "Martin"
last_name = "Westermann '"
space = " "


print(first_name + space +last_name)

fourth_exersize = "bazinga"

print(fourth_exersize[2:6])

print(first_name.upper() + space + last_name.lower())

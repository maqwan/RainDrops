##Using break, write a program that repeatedly asks the user for some
##input and quits only if the user enters "q" or "Q".


should_run = True
##
##def askForInput():
##    value = input("enter something: ")
##    return value
##def EvalInput():
##    Eva_value = askForInput()  
##    if Eva_value == ("q" or "Q"):
##        print("now exiting")
##        
##    else:    
##        print("continuing")


def eval_input(value):
    if value == "Q":
        return False
    elif value == "q":
        return False
    else:
        return True
    
while True:
    value = input("enter something: ")
    test_value = eval_input(value)
    
    if test_value == False:
        print("now exiting")
        break
    else:    
        print("continuing")

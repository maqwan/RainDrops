## 4.7. Streamline Your Print Statements

## 1. Create a string containing an integer, then convert that string into
## an actual integer object using int(). Test that your new object is
## a number by multiplying it by another number and displaying the
## result.
## 2. Repeat the previous exercise, but use a floating-point number and
## float().
## 3. Create a string object and an integer object, then display them side
## by side with a single print statement using str().
## 4. Write a program that uses input() twice to get two numbers from
## the user, multiplies the numbers together, and displays the result.
## If the user enters 2 and 4, then your program should print the
## following text:
## The product of 2 and 4 is 8.0



number_string = "31"

convert_number_string = int(number_string)
multiplication_number = 4

## print(convert_number_string)

print(str(convert_number_string) +" mulitplied with " + str(multiplication_number)+" = " + str(convert_number_string * multiplication_number)) 

float_convert_number_string = 23.4
float_multiplication_number = 5.2

print(str(float_convert_number_string) +" mulitplied with " + str(float_multiplication_number )+" = " + str(float_convert_number_string * float_multiplication_number)) 


print("add two numbers together")
first_number = input("please enter the first number: ")
secound_number = input("please enter the socound number: ")
added_numbers = float(first_number) + float(secound_number)
print(str(first_number)+ " + " + str(secound_number) + " = " + str(added_numbers))

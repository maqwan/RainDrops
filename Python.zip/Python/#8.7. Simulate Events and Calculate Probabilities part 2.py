#8.7. Simulate Events and Calculate Probabilities part 2



def getInt():
    value = int(input("please enter a whole number: "))
    return value
def getString():
    value = str(input("please enter a string value: "))
    return value

def myMethod():
    try:
        s = getString() 
    except:
        "wtf"

    try:
        n = getInt()
    except (IndexError, ValueError):
        print(f"enter a number between 0 and {len(s)}")
        
    try:
       print(s[n])
    except:
       print("something went wrong")
        
 

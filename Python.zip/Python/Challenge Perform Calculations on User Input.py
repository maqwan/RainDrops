# 5.3. Challenge: Perform Calculations on User Input

number_one = float(input("enter first Number: "))
number_two = float(input("enter secound number: "))

answer = (number_one * number_two)

print(f"the answer is {answer}")




